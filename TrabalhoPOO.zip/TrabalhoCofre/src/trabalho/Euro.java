package trabalho;

public class Euro extends Moeda {
	
	public Euro(double valor) {
        super(valor);
    }

    @Override
    public void info() {
        System.out.println("Euro: " + valor);
    }

    // Converte o valor da moeda Euro para Real, supondo que 1 euro seja 6,2 reais
    @Override
    public double converter() {
        return valor * 6.2;

    }

    // Sobrescrevendo o metodo equals
    @Override
    public boolean equals(Object obj) {
        if (!super.equals(obj)) return false; 
        return obj instanceof Euro;
    }
}