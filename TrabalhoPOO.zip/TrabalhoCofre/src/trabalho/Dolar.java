package trabalho;

public class Dolar extends Moeda {
	
	public Dolar(double valor) {
        super(valor);
    }

    @Override
    public void info() {
        System.out.println("Dolar: " + valor);
    }

    // Converte o valor da moeda Dolar para Real, supondo que 1 dolar seja 5,7 reais
    @Override
    public double converter() {
        return valor * 5.7;
    }

    // Sobrescrevendo o metodo equals
    @Override
    public boolean equals(Object obj) {
        if (!super.equals(obj)) return false;
        return obj instanceof Dolar; 
    }
}