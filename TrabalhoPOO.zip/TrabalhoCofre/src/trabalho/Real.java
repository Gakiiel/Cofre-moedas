package trabalho;

public class Real extends Moeda {
    public Real(double valor) {
        super(valor);
    }

    @Override
    public void info() {
        System.out.println("Real: " + valor);
    }

    // Metodo para converter, ja esta em reais
    @Override
    public double converter() {
        return valor;
    }

    // Sobrescrevendo o metodo equals
    @Override
    public boolean equals(Object obj) {
        if (!super.equals(obj)) return false; 
        return obj instanceof Real;
    }
}