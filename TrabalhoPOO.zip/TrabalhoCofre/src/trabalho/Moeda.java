package trabalho;

// Classe abstrata que todas as moedas especificas herdam
public abstract class Moeda {
    protected double valor;

 // Construtor que inicializa o valor da moeda.
    public Moeda(double valor) {
        this.valor = valor;
    }
    // Metodo para exibicao de informacoes
    public abstract void info();
    
    // Metodo para converter o valor da moeda para real
    public abstract double converter();

    
 // Sobrescreve o metodo equals para comparar duas moedas com base no valor.
    @Override
    public boolean equals(Object obj) {
    	
    	// Verifica se e a mesma instancia
    	if (this == obj) return true;
    	
    	// Verifica se e da mesma classe
        if (obj == null || getClass() != obj.getClass()) return false;

        Moeda moeda = (Moeda) obj;
        return Double.compare(moeda.valor, valor) == 0;
    }
}