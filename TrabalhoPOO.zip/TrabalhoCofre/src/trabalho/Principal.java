package trabalho;

import java.util.InputMismatchException;
import java.util.Scanner;

public class Principal {
	
	public static void main(String[] args) {
	
		// Instancia do cofre
		Cofrinho cofrinho = new Cofrinho();
		
		// Scanner para leitura de entradas pelo teclado
		Scanner teclado = new Scanner(System.in);
		
		
		// Menu Principal de interacao dentro de um loop e com tratamento de excecoes
		while(true) {
			try {
				
				System.out.println("---------------Menu---------------");
				System.out.println("1 - Adicionar Moeda");
				System.out.println("2 - Remover Moeda");
				System.out.println("3 - Listar Moedas");
				System.out.println("4 - Calcular total convertido para real");
				System.out.println("5 - Sair");
				System.out.print("Escolha uma opção: ");
				
				int opcao= teclado.nextInt();
							
				
				// Executa a acao com base na opcao escolhida
				 switch (opcao) {
	             
				 case 1:
	                 cofrinho.adicionar(teclado);
	                 break;
	                 
	             case 2:
	                 cofrinho.remover(teclado);
	                 break;
	                   
	             case 3:
	                 cofrinho.listagemMoedas();
	                 break;
	                   
	             case 4:
	                 cofrinho.totalConvertido();
	                 break;
	                    
	             case 5:
	                 System.out.println("Saindo...");
	                 teclado.close();
	                 return;
	                    
	             default:
	                 System.out.println("Opção inválida! Tente novamente.");
	                 break;
				 }
				 
			}
			// Captura entradas invalidas seja letras ou simbolos
			catch (InputMismatchException e) {
                System.out.println("Entrada inválida! Digite um número.");
                teclado.next();
            } catch (Exception e) {
                System.out.println("Ocorreu um erro inesperado: " + e.getMessage());
            }

		}

	}
}
