package trabalho;

import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Scanner;

public class Cofrinho {
	
	// Lista de moedas
	private ArrayList<Moeda> listaMoedas = new ArrayList<Moeda>();
	
	int tipoMoeda;
	double valor = 0;
	
	// Adiciona as moedas de acordo com as escolhas 
	public void adicionar (Scanner teclado) {
		
		while (true) {
			
			try {
				System.out.println("Escolha a moeda");
	            System.out.println("1. Real");
	            System.out.println("2. Dólar");
	            System.out.println("3. Euro");
	            System.out.print("Escolha uma opção: ");
	            tipoMoeda = teclado.nextInt();
	            
	            if (tipoMoeda >= 1 && tipoMoeda <= 3) {
	                while (true) {
	                    System.out.print("Digite o valor: ");
	                    valor = teclado.nextDouble();

	                    if (valor >= 0) { 
	                        break;
	                    }
	                    else {
	                        System.out.println("Valor inválido! Digite um valor positivo.");
	                    }
	                }
	                break;
	            }
	            else {
	                System.out.println("Opção inválida! Digite novamente.");
	            }
	        }
			catch (InputMismatchException e) {
	            System.out.println("Entrada inválida! Digite um número.");
	            teclado.next();
	        }
			catch (Exception e) {
	            System.out.println("Ocorreu um erro inesperado: " + e.getMessage());
	        }
	    }
		
        Moeda moeda = null;

        if (tipoMoeda == 1) {
        	moeda = new Real(valor);
            }
        else if (tipoMoeda == 2) {
        	moeda = new Dolar(valor);
            }
        else if (tipoMoeda == 3) {
        	moeda = new Euro(valor);
            }
           
        if (moeda != null) {
        	listaMoedas.add(moeda);
        	System.out.println("Moeda adicionada com sucesso!");
        }
	}
		

	// Remove as moedas de acordo
	public void remover(Scanner teclado) {

		while (true) {
			
			System.out.println("Escolha qual moeda remover");
			System.out.println("1. Real");
			System.out.println("2. Dólar");
			System.out.println("3. Euro");
			System.out.print("Escolha uma opção: ");
			tipoMoeda = teclado.nextInt();
			
			if (tipoMoeda >=1 && tipoMoeda<=3) {
				System.out.print("Digite o valor: ");
				valor = teclado.nextDouble();
				break;
			}
			else {
				System.out.println("Opção inválida! Digite novamente.");
			}
			
		}
		
		Moeda remover = null;
        if (tipoMoeda == 1) {
        	remover = new Real(valor);
        }
        else if (tipoMoeda == 2) {
            remover = new Dolar(valor);
        }
        else if (tipoMoeda == 3) {
            remover = new Euro(valor);
        }
        
        if(listaMoedas.remove(remover)) {
        	System.out.println("Moeda removida com sucesso!");
        }
        
        else {
        	System.out.println("Moeda não encontrada");
        }

	}


	// Lista as moedas
	public void listagemMoedas() {
		if(listaMoedas.isEmpty()) {
			System.out.println("O cofrinho está vazio.");
		}
		else {
			for (Moeda m : listaMoedas) {
				m.info();
			}
		}
		
	}


	// Converte para real o valor das moedas
	public void totalConvertido() {
		double total = 0;
		for (Moeda m : listaMoedas) {
			total += m.converter();
		}
		System.out.printf("O total convertido para real é: R$ %.2f\n", total);
	}
		
}